#!/bin/bash

# Move files into the appropriate directories
mv ./configFiles/internet_config.sh /home/debian/bin/
mv ./configFiles/pin_config.sh /home/debian/bin/
mv ./configFiles/pin_config.service /home/debian/bin/
mv ./configFiles/setup.sh /home/debian/bin/
mv ./configFiles/internet_config /etc/init.d/

# Set permission for file
chmod 755 /etc/init.d/internet_config

# Prep config file
ln -s /home/debian/bin/pin_config.service /etc/systemd/system/pin_config.service
chmod +x /home/debian/bin/*.sh

# Run config files
bash /home/debian/bin/pin_config.sh
bash /home/debian/bin/setup.sh
bash /home/debian/bin/internet_config.sh

# Create a symbolic link to init network settings on boot
ln -s /etc/init.d/internet_config /etc/rc5.d/S99internet_config

# Reload sources
source /home/debian/.bashrc
systemctl daemon-reload
systemctl enable pin_config
/etc/init.d/networking restart

if ping -q -c 1 -W 1 google.com >/dev/null; then
  echo "The network is up"
else
  echo "The network is down"
  echo "Please recheck your network setting on your Windows computer"
  exit
fi
