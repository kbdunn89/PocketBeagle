#!/bin/sh -e

# motor pins
config-pin p1.06 gpio # DIRR
config-pin p1.30 gpio # DIRL
config-pin p2.10 gpio # nSLPL
config-pin p2.02 gpio # nSLPR
config-pin p1.36 pwm  # PWMR
config-pin p2.01 pwm  # PWML

# motor encoder pins
config-pin p2.33 gpio # ERB
config-pin p2.24 gpio # ELB
config-pin p2.08 gpio # ERA
config-pin p2.29 gpio # ELA

# LED pins
config-pin p2.27 gpio # LEDBR
config-pin p2.17 gpio # LEDBL
config-pin p2.03 gpio # LEDFR
config-pin p2.19 gpio # LEDFL

# bumper pins
config-pin p1.29 gpio # BMP0
config-pin p1.31 gpio # BMP1
config-pin p1.33 gpio # BMP2
config-pin p1.35 gpio # BMP3
config-pin p1.32 gpio # BMP4
config-pin p1.34 gpio # BMP5

# misc
config-pin p2.04 gpio # CTRLE
config-pin p2.06 gpio # CTRLO
config-pin p2.20 gpio # RST

# I'm pretty sure Ain, UART, and I2C are already properly configured

exit 0
