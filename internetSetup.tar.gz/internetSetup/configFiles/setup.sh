#!/bin/bash

echo "alias internet='sudo /var/lib/cloud9/internet_config.sh'" >> ~/.bashrc
echo "alias update='sudo apt update && sudo apt upgrade -y'" >> ~/.bashrc

source ~/.bashrc
